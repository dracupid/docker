#include "test_precomp.hpp"

CV_TEST_MAIN("cv")
